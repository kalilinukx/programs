s=int(input("wqhat is yor age  !"))


print(f"you are {s*365} days older ")