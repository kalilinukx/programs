coordinates=(2, 3, 4)
x,y,z=coordinates
print(x,y,z)