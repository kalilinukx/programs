from sys import exit
people={"Emma":"2819872638",
        "flawless":"2362653",
        "gsdjfgjh":"73645"
        }
if "Emma" in people:
    print(f"found {people['Emma']}")