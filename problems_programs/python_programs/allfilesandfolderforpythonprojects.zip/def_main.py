def flawless():
    for i in range(3):
        cough()



def cough():
    print("Cough")
flawless()