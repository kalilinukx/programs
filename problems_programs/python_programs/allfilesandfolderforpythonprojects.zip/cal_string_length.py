course="pyth on for beginners"
print(len(course))
result=course.lower()
print(result)
print(course.find("o"))
print(course.replace("p","j"))
print(course.title())
print('python' in course)