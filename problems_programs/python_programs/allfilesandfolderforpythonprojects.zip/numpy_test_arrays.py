import numpy as np
print(np.ones(6))
z = np.array([1,0,3])
print(np.sort(z))
print(2*np.zeros(5))