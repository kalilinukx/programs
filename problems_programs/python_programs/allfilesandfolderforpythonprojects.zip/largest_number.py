numbers = [23, 76, 142, 97, 77]
maximum = numbers[0]
for num in numbers:
    if num > maximum:
        maximum = num

print(maximum)
