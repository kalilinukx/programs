store=input("Phone: ")
list={
    "1":"one",
    "2":"two",
    "3":"three",
    "4":"four"
}
for num in store:
    print(list[num],end=" ")