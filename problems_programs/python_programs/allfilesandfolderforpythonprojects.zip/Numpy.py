import numpy as np
import random_number
# arr=np.full((2,3),8)
# print(arr)
# print(arr.shape)
# for entry in arr:
#     print(f'entries are{entry}'     ,end="\n")
#
# new=np.random.rand(6,7)*100
# for entries in new:
#     print(entries,end="\n")
# entry of random numbers
x=np.random.randint(6,size=(4,4))
print(x)
print(np.__version__)