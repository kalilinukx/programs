heroes = ['followers', 'avengers', 'captain america', 'normal man', 'talkyman']

heroes.remove('captain america')
print(heroes)
for hero in heroes:
    print(hero.replace('o', 'k'))

print(heroes)
