birth_year=int(input("enter your birth year :"))
age=2019-birth_year
print("your age is ",+age)
print(type(age ))