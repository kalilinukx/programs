from time import sleep
i=1
while True:
    print(i,end="\n")
    sleep(1)
    i*=2