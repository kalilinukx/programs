is_hot=False
is_cold=True
if is_hot:
    print("it's a hot day")
    print("Drink plenty of water")
elif is_cold:
    print("it's a cold day")
    print("wear warm clothes")

else:
    print("Enjoy your day")
    print("it was a nice meeting with you my dear thank You ")
