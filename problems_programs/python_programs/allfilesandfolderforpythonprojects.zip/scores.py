scores=[]
scores.append(72)
scores.append(73)
scores.append(74)
scores.append(55)
print(f"Average is {sum(scores)/len(scores)}")