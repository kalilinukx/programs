def greet_user(name="flawless"):
    print("hi",name)
    # parameters sre the place holders for the information
    # arguments are the actual informtion that is going to be provided by the user
    #keyword arguments must be defined after the positional arguments

#execution requires the calling of the function
greet_user()
#functions must be called after the definition of the function but i really love the key spacing