prices=[10,20,30]
total=0
for i in prices:
    total+=i
print(f'total cost is {total}')