first="john"
second="smith"
messege=first+"["+ second+"]"+ 'is  a coder'
msg=f'{first}+[{second}] is a coder '
print(msg)