print(10**3)
x=10+3*4
x+=3
x-=5
print(x)
x=6.4
print(x.__round__())
