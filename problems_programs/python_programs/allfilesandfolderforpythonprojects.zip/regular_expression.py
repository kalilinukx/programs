import re
# ^, $, *, +, ?, {, }, [, ], \, |, (, and )
# re.match()
# re.search()
# re.findall()
# re.split()
# re.sub()
# re.compile()
if print(re.match("ab?c")):
    pass