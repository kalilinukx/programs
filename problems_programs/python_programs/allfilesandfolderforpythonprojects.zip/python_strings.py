course="python's for beginners"
print(course[1:-1])
# both will be considered as the value of 0 and end indexes
