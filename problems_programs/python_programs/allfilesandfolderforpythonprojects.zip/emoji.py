dict={
    ":(":"😪",
    ":)":"🤣",
    ":D":"😏"
}
name=input("Please enter your name:")
how_u_feel=input("your feelings: ")
print(f"Hello {name},YOu are feeling{dict[how_u_feel]}")






